package com.company.classes;

public class Peça_mampara_Dades extends Peça_prototipus_Dades{
    private int peça_altura;
    private int peça_amplada;

    public Peça_mampara_Dades(String peça_ID, int peça_num_serie, String peça_nom, String fabricant_ID, boolean peça_reparable, boolean peça_trencada, int peça_altura, int peça_amplada) {
        super(peça_ID, peça_num_serie, peça_nom, fabricant_ID, peça_reparable, peça_trencada);
        this.peça_altura = peça_altura;
        this.peça_amplada = peça_amplada;
    }

    @Override
    public boolean esReparable() {
        return this.isPeça_reparable();
    }
}
