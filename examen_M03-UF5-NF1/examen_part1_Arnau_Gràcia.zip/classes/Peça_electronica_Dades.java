package com.company.classes;

public class Peça_electronica_Dades extends Peça_prototipus_Dades{
    private int peça_consumEnergetic;
    private String peça_consumEnergetic_Unitat_de_mesura;

    public Peça_electronica_Dades(String peça_ID, int peça_num_serie, String peça_nom, String fabricant_ID, boolean peça_reparable, boolean peça_trencada, int peça_consumEnergetic, String peça_consumEnergetic_Unitat_de_mesura) {
        super(peça_ID, peça_num_serie, peça_nom, fabricant_ID, peça_reparable, peça_trencada);
        this.peça_consumEnergetic = peça_consumEnergetic;
        this.peça_consumEnergetic_Unitat_de_mesura = peça_consumEnergetic_Unitat_de_mesura;
    }

    @Override
    public boolean esReparable() {
        return this.isPeça_reparable();
    }
}
