package com.company.classes;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;

public class Drassana_Dades {
    public String nomDrassana = "MCRN Calisto";
    private LinkedList<Nau_Dades> llistaNausEnDrassana;
    private Map<String, Integer>  mapaStockPeces;
    private Map<String, ArrayList<Peça_electronica_Dades>> mapaPecesElectronica;
    private Map<String, ArrayList<Peça_mampara_Dades>> mapaPecesMampares;

    public LinkedList<Nau_Dades> getLlistaNausEnDrassana() {
        return llistaNausEnDrassana;
    }

    public void setLlistaNausEnDrassana(LinkedList<Nau_Dades> llistaNausEnDrassana) {
        this.llistaNausEnDrassana = llistaNausEnDrassana;
    }

    public Map<String, Integer> getMapaStockPeces() {
        return mapaStockPeces;
    }

    public void setMapaStockPeces(Map<String, Integer> mapaStockPeces) {
        this.mapaStockPeces = mapaStockPeces;
    }

    public Map<String, ArrayList<Peça_electronica_Dades>> getMapaPecesElectronica() {
        return mapaPecesElectronica;
    }

    public void setMapaPecesElectronica(Map<String, ArrayList<Peça_electronica_Dades>> mapaPecesElectronica) {
        this.mapaPecesElectronica = mapaPecesElectronica;
    }

    public Map<String, ArrayList<Peça_mampara_Dades>> getMapaPecesMampares() {
        return mapaPecesMampares;
    }

    public void setMapaPecesMampares(Map<String, ArrayList<Peça_mampara_Dades>> mapaPecesMampares) {
        this.mapaPecesMampares = mapaPecesMampares;
    }
}
