package com.company.classes;

import java.util.*;

public class Drassana {

    //1. Inicialitzar naus (part I)
    public static void inicialitzarNaus(Drassana_Dades drassana_MCRN) {
        Nau_Dades nau1 = new Nau_Dades("mcrn 101", "Donnager", null, null);
        Nau_Dades nau2 = new Nau_Dades("mcrn 202", "Pella", null, null);
        Nau_Dades nau3 = new Nau_Dades("mcrn 303", "Carcassone", null, null);

        drassana_MCRN = new Drassana_Dades();

        LinkedList<Nau_Dades> llistaNausEnDrassanaTmp = new LinkedList<Nau_Dades>();

        llistaNausEnDrassanaTmp.add(nau1);
        llistaNausEnDrassanaTmp.add(nau2);
        llistaNausEnDrassanaTmp.add(0, nau3);

        drassana_MCRN.setLlistaNausEnDrassana(llistaNausEnDrassanaTmp);

        for (Nau_Dades nauTmp : drassana_MCRN.getLlistaNausEnDrassana()){
            System.out.println("Drassana "+ drassana_MCRN.nomDrassana +": AFEGIDA LA NAU "+ nauTmp.getNau_nom() +" AMB ID "+ nauTmp.getNau_ID());
        }
    }

    //1. Inicialitzar naus (part II)
    public static void inicialitzarPecesNaus(Drassana_Dades drassana_MCRN) {
        //Tipus radar
        Peça_electronica_Dades peça_radar1 = new Peça_electronica_Dades("Cyrano IV", 0, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", true, true, 120, "kW");
        Peça_electronica_Dades peça_radar2 = new Peça_electronica_Dades("Cyrano IV", 1, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", false, true, 120, "kW");
        Peça_electronica_Dades peça_radar3 = new Peça_electronica_Dades("Cyrano IV", 2, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", true, false, 120, "kW");

        ArrayList<Peça_electronica_Dades> llista_radars = new ArrayList<>(Arrays.asList(peça_radar1, peça_radar2, peça_radar3));

        //Tipus visorIR
        Peça_electronica_Dades peça_visor1 = new Peça_electronica_Dades("SAT SCM2400 Super Cyclone", 0, "cámara d'infrarojos SAT SCM2400 Super Cyclone", "Thomson-CSF", true, false, 5, "kW");
		Peça_electronica_Dades peça_visor2 = new Peça_electronica_Dades("SAT SCM2400 Super Cyclone", 1, "cámara d'infrarojos SAT SCM2400 Super Cyclone", "Thomson-CSF", true, true, 5, "kW");
		Peça_electronica_Dades peça_visor3 = new Peça_electronica_Dades("SAT SCM2400 Super Cyclone", 2, "cámara d'infrarojos SAT SCM2400 Super Cyclone", "Thomson-CSF", true, false, 5, "kW");

        ArrayList<Peça_electronica_Dades> llista_visorsIR = new ArrayList<>(Arrays.asList(peça_visor1, peça_visor2, peça_visor3));

        //Tipus mampara
		Peça_mampara_Dades peça_mampara1 = new Peça_mampara_Dades("mampara de 5x5", 0, "mampara de nanopartícules de grafit de 5 x 5 metres", "Dassault", true, false, 5, 5);
        Peça_mampara_Dades peça_mampara2 = new Peça_mampara_Dades("mampara de 5x5", 1, "mampara de nanopartícules de grafit de 5 x 5 metres", "Dassault", true, true, 5, 5);
        Peça_mampara_Dades peça_mampara3 = new Peça_mampara_Dades("mampara de 5x5", 2, "mampara de nanopartícules de grafit de 5 x 5 metres", "Dassault", true, false, 5, 5);

        ArrayList<Peça_mampara_Dades> llista_mampares = new ArrayList<>(Arrays.asList(peça_mampara1, peça_mampara2, peça_mampara3));

        Iterator<Nau_Dades> nauDadesIterator = drassana_MCRN.getLlistaNausEnDrassana().iterator();

        Nau_Dades nauDadesTmp;

        while (nauDadesIterator.hasNext()){
            nauDadesTmp = nauDadesIterator.next();

        }
    }

    //2. Inicialitzar drassana
    public static void inicialitzarPecesDrassana(Drassana_Dades drassana_MCRN) {

        Map<String, Integer> mapaStockTmp = new HashMap<>();

        Map<String, ArrayList<Peça_electronica_Dades>> mapaPecesElectronica = new HashMap<>();
        Map<String, ArrayList<Peça_mampara_Dades>> mapaPecesMampares = new HashMap<>();

        //Peces_electroniques de tipus radar:
		Peça_electronica_Dades peça_radar1 = new Peça_electronica_Dades("Cyrano IV", 3, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", true, true, 120, "kW");
        Peça_electronica_Dades peça_radar2 = new Peça_electronica_Dades("Cyrano IV", 4, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", false, true, 120, "kW");
        Peça_electronica_Dades peça_radar3 = new Peça_electronica_Dades("Cyrano IV", 5, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", true, false, 120, "kW");
        Peça_electronica_Dades peça_radar4 = new Peça_electronica_Dades("Cyrano IV", 6, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", true, false, 120, "kW");
        Peça_electronica_Dades peça_radar5 = new Peça_electronica_Dades("Cyrano IV", 7, "radar monopulso Thomson-CSF Cyrano IV", "Thomson-CSF", true, false, 120, "kW");

        ArrayList<Peça_electronica_Dades> peces_radar = new ArrayList<Peça_electronica_Dades>(Arrays.asList(peça_radar1, peça_radar2, peça_radar3, peça_radar4, peça_radar5));
        mapaPecesElectronica.put("Cyrano IV", peces_radar);

        int nRadar = peces_radar.size();
        mapaStockTmp.put("Cyrano IV", nRadar);

		//Peces_electroniques de tipus radio:
        Peça_electronica_Dades peça_radio1 = new Peça_electronica_Dades("radio UHF/VHF", 0, "radio salto frecuencias UHF/VHF", "Thomson-CSF", true, false, 10, "kW");
        Peça_electronica_Dades peça_radio2 = new Peça_electronica_Dades("radio UHF/VHF", 1, "radio salto frecuencias UHF/VHF", "Thomson-CSF", true, false, 10, "kW");

        ArrayList<Peça_electronica_Dades> peces_radio = new ArrayList<Peça_electronica_Dades>(Arrays.asList(peça_radio1, peça_radio2));
        mapaPecesElectronica.put("radio UHF/VHF", peces_radio);

        int nRadio = peces_radio.size();
        mapaStockTmp.put("radio UHF/VHF", nRadio);

        //Peces_electroniques de tipus visorIR:
        Peça_electronica_Dades peça_visor1 = new Peça_electronica_Dades("SAT SCM2400 Super Cyclone", 0, "cámara d'infrarojos SAT SCM2400 Super Cyclone", "Thomson-CSF", true, false, 5, "kW");
        Peça_electronica_Dades peça_visor2 = new Peça_electronica_Dades("SAT SCM2400 Super Cyclone", 1, "cámara d'infrarojos SAT SCM2400 Super Cyclone", "Thomson-CSF", true, false, 5, "kW");
        Peça_electronica_Dades peça_visor3 = new Peça_electronica_Dades("SAT SCM2400 Super Cyclone", 2, "cámara d'infrarojos SAT SCM2400 Super Cyclone", "Thomson-CSF", true, false, 5, "kW");

        ArrayList<Peça_electronica_Dades> peces_visor = new ArrayList<Peça_electronica_Dades>(Arrays.asList(peça_visor1, peça_visor2, peça_visor3));
        mapaPecesElectronica.put("SAT SCM2400 Super Cyclone", peces_visor);

        int nVisor = peces_visor.size();
        mapaStockTmp.put("SAT SCM2400 Super Cyclone", nVisor);

        //Peces mampara de tipus mampara5x5:
        Peça_mampara_Dades peça_mampara1 = new Peça_mampara_Dades("mampara de 5x5", 0, "mampara de nanopartícules de grafit de 5 x 5 metres", "Dassault", true, false, 5, 5);
        Peça_mampara_Dades peça_mampara2 = new Peça_mampara_Dades("mampara de 5x5", 1, "mampara de nanopartícules de grafit de 5 x 5 metres", "Dassault", true, false, 5, 5);

        ArrayList<Peça_mampara_Dades> peces_mampara = new ArrayList<Peça_mampara_Dades>(Arrays.asList(peça_mampara1, peça_mampara2));
        mapaPecesMampares.put("mampara de 5x5", peces_mampara);

        int nMampara = peces_mampara.size();
        mapaStockTmp.put("mampara de 5x5", nMampara);

        System.out.println("Drassana MCRN Calisto: ");
        System.out.println("\tAFEGIDES LES PECES ELECTRÓNIQUES: ");
        for (Map.Entry<String, ArrayList<Peça_electronica_Dades>> pecesElectronicaTmp : mapaPecesElectronica.entrySet()){
            ArrayList<Peça_electronica_Dades> peces_electronicaTmp = pecesElectronicaTmp.getValue();
            for (Peça_electronica_Dades peçaElectronicaDadesTmp : peces_electronicaTmp){
                System.out.println("\t\t"+ pecesElectronicaTmp.getKey() +" Nº SERIE "+ peçaElectronicaDadesTmp.getPeça_num_serie());
            }
        }
        System.out.println("\tAFEGIDES LES MAMPARES: ");
        for (Map.Entry<String, ArrayList<Peça_mampara_Dades>> pecesMamparaTmp : mapaPecesMampares.entrySet()){
            ArrayList<Peça_mampara_Dades> peces_mamparaTmp = pecesMamparaTmp.getValue();
            for (Peça_mampara_Dades peçaMamparaDadesTmp : peces_mamparaTmp){
                System.out.println("\t\t"+ pecesMamparaTmp.getKey() +" Nº SERIE "+ peçaMamparaDadesTmp.getPeça_num_serie());
            }
        }

        drassana_MCRN.setMapaStockPeces(mapaStockTmp);
    }

    //10. Drassana: veure stock de peces
    // Veure el nº de peces de repost que hi ha en la drassana.
    // Fer servir un iterador per les claus del mapa.
    public static void veureStockPecesEnDrassana(Drassana_Dades drassana_MCRN) {
        //inicialitzarPecesDrassana(drassana_MCRN);
        Map<String, Integer> stockPecesDrassana = drassana_MCRN.getMapaStockPeces();
        for (Map.Entry<String, Integer> stockPecesTmp : stockPecesDrassana.entrySet()){
            System.out.println(stockPecesTmp.getKey() + ": " + stockPecesTmp.getValue());
        }
    }

}
