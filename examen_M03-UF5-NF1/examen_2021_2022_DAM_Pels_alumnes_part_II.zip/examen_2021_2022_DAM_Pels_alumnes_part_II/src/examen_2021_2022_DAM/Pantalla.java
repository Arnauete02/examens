/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_2021_2022_DAM;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.SortedSet;

import Pantalles.MenuConstructorPantalla;

/**
 *
 * @author gmartinez
 */
public class Pantalla {
	
	public static void bloquejarPantalla(Scanner sc) {
        System.out.println();
        System.out.print("Toca 'C' per a continuar ");
        while (sc.hasNext()) {
            if ("C".equalsIgnoreCase(sc.next())) break;
        }
        System.out.println();
        System.out.println();
    }
    

	public static void main(String[] args) {
		String opcio;
        Scanner sc = new Scanner(System.in);
        StringBuilder menu = new StringBuilder("");
        
        Drassana_Dades drassana_MCRN = new Drassana_Dades();
        XXX resultatMenu12 = null;

        do {
        	menu.delete(0, menu.length());
            
            menu.append(System.getProperty("line.separator"));
            menu.append(Drassana_Dades.nomDrassana);
            menu.append(System.getProperty("line.separator"));
            menu.append(System.getProperty("line.separator")); 
            
            menu.append("1. Inicialitzar naus");
            menu.append(System.getProperty("line.separator"));
            menu.append("2. Inicialitzar drassana");
            menu.append(System.getProperty("line.separator"));
            menu.append(System.getProperty("line.separator"));
            
            menu.append("10. Drassana: veure stock de peces");
            menu.append(System.getProperty("line.separator"));
            menu.append("11. Drassana: veure stock de peces ordenades pel nom (per la clau)");
            menu.append(System.getProperty("line.separator"));
            menu.append("12. Drassana: peces trencades de les naus");
            menu.append(System.getProperty("line.separator"));
            menu.append("13. Drassana: restar d'stock les peces trencades de les naus");
            menu.append(System.getProperty("line.separator"));
            menu.append("14. Drassana: reparar els radars trencats de les naus");
            menu.append(System.getProperty("line.separator"));
            menu.append(System.getProperty("line.separator"));
            
            menu.append("50. Tornar al menú pare (PNS-24 Puma )");
            menu.append(System.getProperty("line.separator"));
            
            
            System.out.print(MenuConstructorPantalla.constructorPantalla(menu));
            
            opcio = sc.next();

            switch (opcio) {
                case "1":
                	Drassana.inicialitzarNaus(drassana_MCRN);
                	System.out.println();
                	Drassana.inicialitzarPecesNaus(drassana_MCRN);
                	System.out.println();
                	
                    bloquejarPantalla(sc);
                    break;
                    
                case "2":
                	Drassana.inicialitzarPecesDrassana(drassana_MCRN);
                	
                    bloquejarPantalla(sc);
                    break;

                case "10":
                	Drassana.veureStockPecesEnDrassana(drassana_MCRN);
                    
                	bloquejarPantalla(sc);
                    break;
                    
                case "11":
                	Drassana.veureStockPecesEnDrassanaOrdenatPerClau(drassana_MCRN);
                    
                	bloquejarPantalla(sc);
                    break;

                case "12":
                	resultatMenu12 = Drassana.pecesTrenacadesDeNausVSPecesRecanviDrassana(drassana_MCRN);
                    
                	bloquejarPantalla(sc);
                    break;
                    
                case "13":
                	Drassana.ferComandaPeces(drassana_MCRN, resultatMenu12);
                    
                	bloquejarPantalla(sc);
                    break;
                case "14":
                	Drassana.repararNaus(drassana_MCRN);
                    
                	bloquejarPantalla(sc);
                    break;
                 
                case "50":
                    break; 
                    
                default:
                    System.out.println("ERROR: COMANDA NO RECONEGUDA");
                    System.out.println();
            }   

        } while (!opcio.equals("50"));
    }    
}
